export async function register() {
  // Instrumentation disabled for now
  console.log('Instrumentation hook registered')
}