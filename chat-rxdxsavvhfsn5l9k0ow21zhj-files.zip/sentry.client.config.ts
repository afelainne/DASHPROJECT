// Sentry configuration disabled for now
// TODO: Install @sentry/nextjs when needed